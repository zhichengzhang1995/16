//cards.h
//Kenny Zhang
//All class declarations go here

#ifndef CARDS_H
#define CARDS_H
#include<string>
class Cards{

public:


    Cards();              // constructor
    void print() const;     // print cards of an owner
    int count() const;      // return number of cards
    void append(std::string s); // add a card to the linked list
    ~Cards();                      // destructor

    bool contains(std::string k) const;  // true if card in list
    void show_result(Cards& Cards_1, Cards& Cards_2);

    Cards& operator=(const Cards& source); //overloaded 

private:

    // definition of Node structure :
    struct Node {
      ~Node();
      std::string card;
        Node *next;
    };

    Node *first; // pointer to first node
};

#endif
