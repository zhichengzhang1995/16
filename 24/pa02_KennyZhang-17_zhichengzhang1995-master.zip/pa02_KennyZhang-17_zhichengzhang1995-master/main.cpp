#include <iostream>
#include <fstream>
#include <string>
#include "cards.h"
using namespace std;

int main(int argv, char** argc){
  if(argv < 3){
    cout << "Please provide 2 file names" << endl;
    return 1;
  }
  
  ifstream cardFile1 (argc[1]);
  ifstream cardFile2 (argc[2]);
  string line;

  if (cardFile1.fail() || cardFile2.fail() ){
    cout << "Could not open file " << argc[2];
    return 1;
  }
  //create two cards object
  Cards card1, card2;
  //Read each file
  while (getline (cardFile1, line) && (line.length() > 0)){
    card1.append(line);
  }
  cardFile1.close();


  while (getline (cardFile2, line) && (line.length() > 0)){
    card2.append(line);
  }
  cardFile2.close();
  
  show_result(card1, card2);
  
  return 0;
}
