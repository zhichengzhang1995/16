//cards.cpp
//Kenny Zhang
//Implementation of the classes defined in cards.h
#include "cards.h"
#include <string>
#include <iostream>
using std::cout;
using namespace std;
    // constructor create empty list
    Cards::Cards(){
        first=0;
    } 
    // print cards of an owner
    void Cards::print() const{
        Node* n=first;
        while(n)//n is not empty
        {
            cout<<n->card<<endl;
            n=n->next;
        }
    }     
    // return number of cards
    int Cards::count() const{
        int result = 0;
        Node *n = first;
        while (n) {
            ++result;
            n = n->next;
    }
    return result;
    }
    void Cards::append(string s){
    if (!first) { //if first is empty
        first = new Node;
        first->card = s;
        first->next = 0;
    }
    else {
        Node* result = first;
        while (result->next){ // go to the last node
            result = result->next;
            }
        result->next = new Node;
        result->next->card = s;
        result->next->next = 0;
        }
    }

    // destructor by recursion
    Cards::~Cards(){
         delete first;// call node destructor
    }
Cards::Node::~Node(){
  if(next!=0)
    {delete (next);}
}
                           

    //true if card in list
    bool Cards::contains(string k) const{
        Node *n = first;
        bool result=0;
    while (n) {
        if(n->card==k){
            result=true;
        }
        n = n->next;
    } 
    return result; 
    }
    //show the result of the game
    void Cards::show_result(Cards &Cards_1, Cards &Cards_2){
        Node *n = Cards_1.first;
        Node *temp=0;
        int count=0;
        bool result=0;
    while (n->next) {
        if(Cards_2.contains(n->next->card)&& (count %2 ==0)){
            cout<<"Alice picked matching card "<<n->next->card<<endl;
            Node *k=Cards_2.first;
            while(k->next->card!=n->next->card){
                k=k->next;
            }
        temp=k->next;
            //delete k->next;
        if(temp->next){
          k->next=temp->next;}
        else{k->next=0;}
            temp=n->next;
            //delete n->next;
            if(temp->next){
          n->next=temp->next;}
        else{n->next=0;}
        count=count+1;
        }
        else if(Cards_2.contains(n->next->card)&&(count%2==1)){
            cout<<"Bob picked matching card "<<n->next->card<<endl;
            Node *k=Cards_2.first;
            while(k->next->card!=n->next->card){
                k=k->next;
            }
            temp=k->next;
        if(temp->next){
          //  delete k->next;
          k->next=temp->next;}
        else{k->next=0;}
            temp=n->next;
        // delete n->next;
        if(temp->next){
          n->next=temp->next;}
        else{n->next=0;}
            count=count+1;
        }
    n=n->next;
    }
    cout<<endl;
    cout<<"Alice's cards:"<<endl;
        Cards_1.print();
        cout<<"Bob's cards:"<<endl;
        Cards_2.print();
    }
    //overloaded
    Cards& Cards::operator==(const Cards& source){
        return *this;//this is a stub
    } 